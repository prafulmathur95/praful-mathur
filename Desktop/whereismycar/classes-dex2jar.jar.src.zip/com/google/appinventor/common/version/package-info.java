package com.google.appinventor.common.version;

interface package-info {}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\common\version\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */