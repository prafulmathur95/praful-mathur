package com.google.appinventor.components.runtime;

import android.view.ViewGroup;

public abstract interface Layout
{
  public abstract void add(AndroidViewComponent paramAndroidViewComponent);
  
  public abstract ViewGroup getLayoutManager();
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\Layout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */