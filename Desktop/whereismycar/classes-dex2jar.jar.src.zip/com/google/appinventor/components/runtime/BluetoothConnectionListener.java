package com.google.appinventor.components.runtime;

abstract interface BluetoothConnectionListener
{
  public abstract void afterConnect(BluetoothConnectionBase paramBluetoothConnectionBase);
  
  public abstract void beforeDisconnect(BluetoothConnectionBase paramBluetoothConnectionBase);
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\BluetoothConnectionListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */