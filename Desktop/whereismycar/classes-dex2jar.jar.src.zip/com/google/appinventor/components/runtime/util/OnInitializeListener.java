package com.google.appinventor.components.runtime.util;

public abstract interface OnInitializeListener
{
  public abstract void onInitialize();
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\util\OnInitializeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */