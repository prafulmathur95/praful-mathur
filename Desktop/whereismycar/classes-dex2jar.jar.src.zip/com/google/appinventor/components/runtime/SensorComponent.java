package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.SimpleObject;

@SimpleObject
public abstract interface SensorComponent
  extends Component
{}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\SensorComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */