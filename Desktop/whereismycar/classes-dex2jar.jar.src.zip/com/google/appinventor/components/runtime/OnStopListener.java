package com.google.appinventor.components.runtime;

public abstract interface OnStopListener
{
  public abstract void onStop();
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\OnStopListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */