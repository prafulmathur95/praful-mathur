package com.google.appinventor.components.runtime.util;

import gnu.mapping.SimpleSymbol;

public class YailConstants
{
  public static final SimpleSymbol YAIL_HEADER = new SimpleSymbol("*list*");
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\com\google\appinventor\components\runtime\util\YailConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */