package gnu.bytecode;

public abstract interface Filter
{
  public abstract boolean select(Object paramObject);
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\bytecode\Filter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */