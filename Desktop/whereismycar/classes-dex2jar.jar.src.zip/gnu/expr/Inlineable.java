package gnu.expr;

public abstract interface Inlineable
{
  public abstract void compile(ApplyExp paramApplyExp, Compilation paramCompilation, Target paramTarget);
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\expr\Inlineable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */