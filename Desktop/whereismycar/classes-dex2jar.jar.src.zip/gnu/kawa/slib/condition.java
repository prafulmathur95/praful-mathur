package gnu.kawa.slib;

public class condition
  extends RuntimeException
{
  public Object type$Mnfield$Mnalist;
  
  public condition(Object paramObject)
  {
    this.type$Mnfield$Mnalist = paramObject;
  }
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\kawa\slib\condition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */