package gnu.kawa.models;

public abstract interface Viewable
{
  public abstract void makeView(Display paramDisplay, Object paramObject);
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\kawa\models\Viewable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */