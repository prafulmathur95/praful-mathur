package gnu.kawa.models;

public abstract interface ModelListener
{
  public abstract void modelUpdated(Model paramModel, Object paramObject);
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\kawa\models\ModelListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */