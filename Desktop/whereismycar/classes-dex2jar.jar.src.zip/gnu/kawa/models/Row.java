package gnu.kawa.models;

public class Row
  extends Box
  implements Viewable
{
  public int getAxis()
  {
    return 0;
  }
}


/* Location:              C:\Users\User\Desktop\dex2jar-2.0\classes-dex2jar.jar!\gnu\kawa\models\Row.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */